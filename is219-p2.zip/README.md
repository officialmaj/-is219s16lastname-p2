The initial start of a functioning Photo Gallery. 

Some HTML, CSS, and Javascript have already been created. 
Using jQuery, position the necessary elements to make the application look like the info/finished_gallery.png.

Leave the index.php file alone. It is used to make sure your Heroku server deploys correctly with PHP functionality and also  automatically redirects visitors to index.html.


There are several JSON files you can use for your gallery for testing:

images.json: default image gallery of different places around the world. Uses local image files.
images-short.json: a image gallery that can be used for testing.